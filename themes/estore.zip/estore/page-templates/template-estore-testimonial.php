<?php
/**
 * Template Name: eStore Testimonial
 *
 * @package ThemeGrill
 * @subpackage eStore
 * @since 1.0
 */

get_header(); ?>

	<div id="content" class="clearfix">

	<section>
		<?php
		
				$homePageTestimonials=new WP_Query(array(
					'posts_per_page'=>2,
					'post_type'=>'testimonial'
				));
				while ($homePageTestimonials->have_posts()) {
					$homePageTestimonials->the_post();
					get_template_part('template-parts/content', 'event');
				}
		?>
	</section>

	</div>

<?php get_footer(); ?>
