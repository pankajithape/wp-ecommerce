<div class="event-summary">
  <div class="event-summary__content">
    <h5 class="event-summary__title headline headline--tiny"><a href="<?php the_permalink(); ?>"><?php echo get_field('testimonial_name'); ?></a></h5>
    <p><?php echo get_field('testimonial_position'); ?></p>
    <p><?php echo get_field('testiomonial_comment'); ?></p>
    <img class="img-fluid" src="<?php echo get_field('testimonial_profile_photo')['sizes']['medium'];?>" alt="">
  </div>
</div>